<?php 
#Silence is golden.